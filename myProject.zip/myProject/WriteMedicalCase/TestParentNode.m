//
//  TestParentNode.m
//  MedicalCase
//
//  Created by ihefe-JF on 15/4/9.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import "TestParentNode.h"


@implementation TestParentNode

@dynamic nodeName;
@dynamic testNodes;

+(NSString*)entityName
{
    return @"TestParentNode";
}
@end
