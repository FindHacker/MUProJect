//
//  personInfoView.h
//  MedicalCase
//
//  Created by GK on 15/4/28.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface personInfoView : UIView
@property (nonatomic) BOOL isHideSubView;

@end
