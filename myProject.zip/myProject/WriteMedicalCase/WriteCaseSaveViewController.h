//
//  WriteCaseSaveViewController.h
//  WriteMedicalCase
//
//  Created by GK on 15/4/29.
//  Copyright (c) 2015年 GK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WriteCaseSaveViewController : UIViewController
@property (nonatomic,strong) RecordBaseInfo *recordCase;

@end
