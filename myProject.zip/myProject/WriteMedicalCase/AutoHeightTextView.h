//
//  AutoHeightTextView.h
//  MedicalCase
//
//  Created by ihefe-JF on 15/4/21.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AutoHeightTextView;

@interface AutoHeightTextView : UITextView <UITextViewDelegate>

@end
