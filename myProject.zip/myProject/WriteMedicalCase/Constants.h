//
//  Constants.h
//  MedicalCase
//
//  Created by ihefe-JF on 15/4/2.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#ifndef MedicalCase_Constants_h
#define MedicalCase_Constants_h

static NSString *selectedConditionResultString = @"selectedConditionResultString";
static NSString *selectedModelResultString = @"selectedModelResultString";

static NSString *kDidSelectedFinalTemplate = @"kDidSelectedFinalString";
static NSString *selectedTemplateClassification = @"selectedTemplateClassification";
static NSString *didExcutePopoverConditionSegue = @"DidExcutePopoverConditionSegue";


///core data notification
static NSString *kDidCompletedAsyncInitEntity = @"kDidCompletedAsyncInitEntity";
#endif
