//
//  WLKTemplate.m
//  MedCase
//
//  Created by ihefe36 on 14/12/31.
//  Copyright (c) 2014年 ihefe. All rights reserved.
//

#import "WLKTemplate.h"
#import "WLKCaseNode.h"
@implementation WLKTemplate

@end
