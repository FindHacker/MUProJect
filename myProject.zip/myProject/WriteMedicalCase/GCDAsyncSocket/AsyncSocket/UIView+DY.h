//
//  UIView+DY.h
//  community
//
//  Created by ihefe33 on 3/19/15.
//  Copyright (c) 2015 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (DY)

+(void)viewWithMessage:(NSString *)message toView:(UIView *)view;


@end
