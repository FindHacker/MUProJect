//
//  CKObject.m
//  MedImageReader
//
//  Created by ihefe36 on 14/12/29.
//  Copyright (c) 2014年 ihefe. All rights reserved.
//

#import "WLKObject.h"

@implementation WLKObject

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    if (self = [super init]) {
        
    }
    return self;
}
- (instancetype)initWithArray:(NSArray *)array
{
    if (self = [super init]) {
        
    }
    return self;
}
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    return self;
}
@end
