//
//  CustomSegue.h
//  MedicalCase
//
//  Created by ihefe-JF on 15/4/22.
//  Copyright (c) 2015年 ihefe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomSegue : UIStoryboardSegue


@end
